﻿using System.Windows;
using Eksamen.ViewModels;
using Eksamen.Models;

namespace Eksamen.Views;

/// <summary>
/// Interaction logic for CreateBoardGameView.xaml
/// </summary>
public partial class CreateBoardGameView : Window
{
    public CreateBoardGameView() {
        InitializeComponent();
    }
}
