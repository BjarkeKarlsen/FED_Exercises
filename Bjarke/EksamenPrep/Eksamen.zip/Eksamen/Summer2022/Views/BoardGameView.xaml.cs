﻿using System.Windows;

namespace Eksamen.Views;

/// <summary>
/// Interaction logic for PackageListView.xaml
/// </summary>
public partial class BoardGameView : Window
{
    public BoardGameView()
    {
        InitializeComponent();
    }
}
